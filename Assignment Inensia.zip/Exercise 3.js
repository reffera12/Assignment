function descendantsToArray(){
    var descendants = Array.from(document.querySelectorAll("ul *"));
    descendants.forEach(descendant => {
        console.log(descendant);
    });
}